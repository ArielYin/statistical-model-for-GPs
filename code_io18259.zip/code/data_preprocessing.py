import numpy as np
import csv
import re
import fractions

cluster = np.load('frontal/spike_clusters.npy').tolist()
spikeT = np.load('frontal/spike_times.npy').tolist()

# the 2d list containing spiking time and cluster id
times = []

goodData = []

# sort out good data
with open('frontal/cluster_groups.csv') as csvDataFile:
    csvReader = csv.reader(csvDataFile)
    for row in csvReader:
        result = 'good' in row[0]
        if result is True:
            group_id = re.findall(r"\d+", row[0])
            group_id = map(int, group_id)
            goodData.append(group_id)
    print(len(goodData))
    print('--')
    print(goodData)
    print('--')

length = 5

# spike time of  n good data
i = 0
while i < length:
    each_group_time = []
    cluster_position = []
    j = goodData[i][0]
    print j
    print('>>')
    for index, item in enumerate(cluster):
        if j == item:
            cluster_position.append(index)
    for item_a in cluster_position:
        each_group_time.append(spikeT[item_a])
    print(each_group_time)
    ss = sum(each_group_time, [])
    print(ss)
    times.append(ss)
    i += 1
    print i

# covert ss into matrix with 0 and 1
max_list = []
min_list = []
k = 0
while k < length:
    max_list.append(max(times[k]))
    min_list.append(min(times[k]))
    k += 1
max_num = max(max_list)
min_num = min(min_list)

time_bin = 1  # s
interval_num = int((max_num - min_num)/3000/time_bin) + 1
print('##')
print(interval_num)
print('##')

# init a matrix with cluster id and interval number
new_list = [([0] * length) for h in range(interval_num)]
r = 0
while r < length:
    for time_num in times[r]:
        new_list[int((time_num - min_num)/3000/time_bin)][r] = 1
    r += 1
print len(new_list)

# # store the matrix in file
# test_csv = pd.DataFrame(data=new_list)
# test_csv.to_csv('csv40.csv', encoding='gbk')

# how many neurons spiked at each bin
row = map(sum, new_list)
print(row)

# conditional probability
sum_row = len(row)
print('""')
print sum_row
print('""')

first = np.zeros(length, int).tolist()
cp_whole = [first]
q = 1
new_index_list = []
while q < length:
    index_list = []  # the row index of each K
    for each_index, each_num in enumerate(row):
        if each_num == q:
            index_list.append(each_index)
    new_index_list.append(len(index_list))
    # q += 1
# plt.bar(range(len(new_index_list)), new_index_list)
# plt.show()
    p = 0
    cp = []
    while p < length:
        xp_count = 0
        for index_num in index_list:
            if new_list[index_num][p] == 1:
                xp_count += 1
        if len(index_list) == 0:
            x = 0
        else:
            x = fractions.Fraction(xp_count, len(index_list))
        cp.append(x)
        p += 1
    cp_whole.append(cp)
    q += 1
last = np.ones(length, int).tolist()
cp_whole.append(last)
print cp_whole


# store the matrix in file
np.save("cp5_timebin1.npy", cp_whole)






