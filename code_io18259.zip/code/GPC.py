import numpy as np
from matplotlib import pyplot as plt
import datetime
import psutil
from fractions import Fraction
from sklearn.gaussian_process import GaussianProcessClassifier
from sklearn.gaussian_process.kernels import RBF, ConstantKernel as C, WhiteKernel as W

bb = []  # 2d list for prediction
cc = []  # 2d list for observation

startime = datetime.datetime.now()
c = np.load("cp5_timebin10.npy", allow_pickle=True)
print(c)
length = len(c)
fake_x0 = np.zeros(100, int)
X = np.arange(length)
fake_x1 = np.full(100, length-1)
X = np.concatenate((fake_x0, X), axis=0)
X = np.concatenate((X, fake_x1), axis=0)
X = np.atleast_2d(X).T

fake_data0 = np.zeros([100, length-1], int)
fake_data1 = np.ones([100, length-1], int)
c = np.concatenate((fake_data0, c), axis=0)
c = np.concatenate((c, fake_data1), axis=0)

i = 0
while i < length-1:
    a = []
    column = c[:, i]
    new_col = np.zeros(len(X))
    for index, each in enumerate(column):
       if each > Fraction(1, 2):
           new_col[index] = 1

    # store observation P(xi|K) in cc
    cc.append(column)
    # Observations
    y = new_col

    # prediction x
    kernel = C(0.2, (1e-3, 1)) * RBF(0.5, (1e-2, 1)) + W(noise_level=0.1, noise_level_bounds=(1e-5, 1))
    gp = GaussianProcessClassifier(kernel=kernel, n_restarts_optimizer=100)
    gp.fit(X, y)
    X_ = np.linspace(0, 5, 100)
    pp = gp.predict_proba(X_[:, np.newaxis])
    bb.append(pp)
    i += 1

# time
endtime = datetime.datetime.now()
print(endtime-startime).seconds

# memory
info = psutil.virtual_memory()
print(info.used)  # memory used
print(info.total)  # total memory
print(info.percent)  # percentage
print(psutil.cpu_count())  # cpu number

plt.figure()

for i in range(len(bb)):
    # plt.scatter(X, cc[i], edgecolors=(0, 0, 0))
    plt.plot(X_, bb[i][:, 1])


plt.xlabel('$Neuron\ co-active\ N\ (10ms\ time\ bins)$')
plt.ylabel('$P(xi|K)$')
plt.title("Initial: %s\nOptimum: %s\nLog-Marginal-Likelihood: %s"
            % (kernel, gp.kernel_,
                gp.log_marginal_likelihood(gp.kernel_.theta)))
plt.show()

#gpc5 115s
# 85204992
# 17103466496
# 49.4
# 8

#gpc40 1734
# 83599360
# 17103466496
# 48.9
# 8