from scipy import stats
import numpy as np
import matplotlib.pyplot as plt
import math

from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, ConstantKernel as C, WhiteKernel as W


def slice_sampling(binom):
    iter = 100
    samples = np.zeros(iter)

    for i in range(iter):
        u = np.random.choice(binom)
        itemindex = np.argwhere(binom == u)
        if len(itemindex)>1:
            c = [i for i in range(itemindex[0][0], itemindex[1][0])]
            x = np.random.choice(c)
        else:
            x =itemindex[0][0]
        samples[i] = x

    return samples


c = np.load("cp5_timebin10.npy", allow_pickle=True)
print(c)
length = len(c)
fig, ax = plt.subplots(1, 1)
mean_w = []
var_w = []
pred_w = []
j = 0
while j < length-1:

    i = 0
    mean = []
    var = []
    while i < length:
        n = 100
        k = np.arange(n+1)
        p = float(c[i][j])
        binom1 = stats.binom.pmf(k, n, p)
        sample = slice_sampling(binom1)
        print(sample)
        ax.plot(k, stats.binom.pmf(k, n, p), 'bo', ms=8, label='binom pmf')
        p_value = []
        for x_value in sample:
            p_value.append(binom1[int(x_value)])
        print(p_value)
        print('---')
        y_sample = []
        for p in p_value:
            if p == 0.0:
                y_sample.append(int(-1000))
            if p == 1.0:
                y_sample.append(int(1000))
            else:
                # z = np.log(p) - np.log(1 - p)
                # if z == float('-inf'):
                #     y_sample.append(int(-1000))
                # if z == float('inf'):
                #     y_sample.append(int(1000))
                y_sample.append(np.log(p) - np.log(1 - p))
        # y_sample = y_sample[~y_sample.isin([np.nan, np.inf, -np.inf]).any(1)]

        print(y_sample)
        print('%%%')
        mean.append(np.mean(y_sample))
        var.append(np.var(y_sample))
        print('%%%')
        i += 1
    print('***')
    mean_w.append(mean)
    var_w.append(var)
    j += 1

print(len(mean_w))


X = np.arange(length)
X = np.atleast_2d(X).T
k = 1
while k < length-2:
    column = mean_w[k]
    y = np.array(column)
    y[np.isnan(y)]=0
    y[np.isinf(y)]=1000
    print(type(y))

    x = np.atleast_2d(np.linspace(0, 40, 100)).T

    alph = np.array(var_w[k])
    alph[np.isnan(alph)] = 0
    alph[np.isinf(alph)] = 1000
    kernel = C(0.2, (1e-3, 1e3)) * RBF(0.3, (1e-2, 0.7)) + W(noise_level=0.3, noise_level_bounds=(1e-2, 1))
    gp = GaussianProcessRegressor(kernel=kernel, n_restarts_optimizer=50, normalize_y=True,
                                  alpha=alph)
    gp.fit(X, y)
    y_pred, sigma = gp.predict(x, return_std=True)
    y_pred = y_pred.tolist()
    print(y)
    print(y_pred)
    pred_w.append(y_pred)
    k += 1

length1 = len(pred_w[1])
print(length1)
print(type(pred_w[1]))
print('%%%')
m = 0
yp = []
plt.figure(2)
while m < length1:
    x1 = [i[m] for i in pred_w]
    meanx = np.mean(x1)
    print(meanx)
    try:
        meany = 1/(1 + math.exp(-meanx))
    except OverflowError:
        meany = float('inf')

    plt.scatter(m, meany, edgecolors=(0, 0, 0))
    m += 1
plt.show()
