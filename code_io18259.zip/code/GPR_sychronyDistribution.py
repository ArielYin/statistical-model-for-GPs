import numpy as np
from matplotlib import pyplot as plt

from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, ConstantKernel as C, WhiteKernel as W


c = np.load("sd40.npy", allow_pickle=True)
length = len(c)
X = np.arange(length)
X = np.atleast_2d(X).T
print(c)

c.tolist()
sum2 = sum(c)
p2 = [float(i)/sum2 for i in c]
print(p2)
x = np.atleast_2d(np.linspace(0, 40, 80)).T

kernel = C(0.2, (1e-3, 1e3)) * RBF(0.2, (1e-4, 1)) + W(noise_level=0.005, noise_level_bounds=(2e-4, 1e-2))
gp = GaussianProcessRegressor(kernel=kernel, n_restarts_optimizer=10, normalize_y=True)

gp.fit(X, p2)

y_pred, sigma = gp.predict(x, return_std=True)
print(y_pred)


plt.figure()

plt.plot(x, y_pred, '-', label='Prediction')
plt.plot(X, p2, '.', label='Observation')
plt.xlabel('$Neuron\ co-active\ N\ (10ms\ time\ bins)$')
plt.ylabel('$Probability$')
plt.show()
