import numpy as np
from matplotlib import pyplot as plt
import datetime
import psutil
import pandas as pd

from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, ConstantKernel as C, WhiteKernel as W

startime = datetime.datetime.now()
bb = []  # 2d list for prediction
cc = []  # 2d list for observation
np.random.seed(1)
c1 = np.load("cp5_timebin10.npy", allow_pickle=True)
length = len(c1)
fake_x0 = np.zeros(100, int)
X = np.arange(length)
fake_x1 = np.full(100, length-1)
X = np.concatenate((fake_x0, X), axis=0)
X = np.concatenate((X, fake_x1), axis=0)
X = np.atleast_2d(X).T

fake_data0 = np.zeros([100, length-1], int)
fake_data1 = np.ones([100, length-1], int)
c = np.concatenate((fake_data0, c1), axis=0)
c = np.concatenate((c, fake_data1), axis=0)


def div(x):
    return x/len(c)


col = map(sum, zip(*c))
print(col)
col = map(div, col)  # the mean value of each cluster
weidth = len(col)
heigth = len(c)
relative_uncertainty = [([0]*weidth) for z in range(heigth)]
cluster_id = 0
while cluster_id < weidth:
    value = 0
    while value < heigth:
        relative_uncertainty[value][cluster_id] = (c[value][cluster_id]-col[cluster_id])/col[cluster_id]
        value += 1
    cluster_id += 1
relative_uncertainty = map(np.abs, relative_uncertainty)
relative_uncertainty = np.array(relative_uncertainty)
relative_uncertainty = relative_uncertainty.astype(int)

i = 0
while i < length-1:
    column = c1[:, i]
    # Observations
    y = column
    # store input p(xi|k) in observation list
    cc.append(y)
    # prediction x
    x = np.atleast_2d(np.linspace(0, 5, 100)).T

    kernel = C(0.2, (1e-3, 1)) * RBF(1, (1e-2, 1e1)) + W(noise_level=0.1, noise_level_bounds=(1e-7, 1))
    gp = GaussianProcessRegressor(kernel=kernel, n_restarts_optimizer=50, normalize_y=True, alpha=relative_uncertainty[:, i])
    # gp = GaussianProcessRegressor(kernel=kernel, n_restarts_optimizer=50, normalize_y=True)
    # #without relative uncertainty
    gp.fit(X, y)

    y_pred, sigma = gp.predict(x, return_std=True)
    print(i)
    print('---')

    # store the prediction P(xi|k) in prediction list
    bb.append(y_pred)
    i += 1

test_csv = pd.DataFrame(data=bb)
test_csv.to_csv('pre5_50.csv', encoding='gbk')

# time
endtime = datetime.datetime.now()
print(endtime-startime).seconds

# space
info = psutil.virtual_memory()
print(info.used)  # memory used
print(info.total)  # total memory
print(info.percent)  # percentage
print(psutil.cpu_count())  # cpu number

plt.figure()
for i in range(len(bb)):

    plt.plot(x, bb[i], markersize=10, label='Observations %d' % i)
    plt.scatter(X, cc[i], edgecolors=(0, 0, 0), label='Prediction %d' % i)
    font2={'size' : 20}
    plt.xlabel('$Neuron\ co-active\ N\ (10ms\ time\ bins)$', font2)
    plt.ylabel('$P(xi|K)$', font2)
    plt.legend()
    plt.tick_params(labelsize=20)
    plt.title("Initial: %s\nOptimum: %s\nLog-Marginal-Likelihood: %s"
              % (kernel, gp.kernel_,
                 gp.log_marginal_likelihood(gp.kernel_.theta)), font2)
plt.show()


