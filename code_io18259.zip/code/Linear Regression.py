import matplotlib.pyplot as plt
import numpy as np
from sklearn import datasets, linear_model
import datetime
import psutil

startime = datetime.datetime.now()
bb = []
cc = []
# Use only one feature
c = np.load("cp40_timebin10.npy", allow_pickle=True)
length = len(c)
fake_x0 = np.zeros(20, int)
X = np.arange(length)
fake_x1 = np.full(20, length-1)
X = np.concatenate((fake_x0, X), axis=0)
X = np.concatenate((X, fake_x1), axis=0)
X = np.atleast_2d(X).T

fake_data0 = np.zeros([20, length-1], int)
fake_data1 = np.ones([20, length-1], int)
c = np.concatenate((fake_data0, c), axis=0)
c = np.concatenate((c, fake_data1), axis=0)
i = 0
while i < length-1:
    a = []
    column = c[:, i]
    # store P(xi|K) in cc
    cc.append(column)
    # Observations
    y = column
    # prediction x
    x = np.atleast_2d(np.linspace(0, 40, 100)).T

    regr = linear_model.LinearRegression()
    regr.fit(X, y)
    y_pred = regr.predict(x)

    # store the prediction P(xi|k) in bb
    bb.append(y_pred)
    i += 1

endtime = datetime.datetime.now()
print(endtime-startime).seconds

info = psutil.virtual_memory()
print(info.used)  # memory taken up
print(info.total)  # total memory
print(info.percent)  # percentage
print(psutil.cpu_count())  # cpu number


# The mean squared error
# print("Mean squared error: %.2f"
#     % mean_squared_error(diabetes_y_test, diabetes_y_pred))
# Explained variance score: 1 is perfect prediction
# print('Variance score: %.2f' % r2_score(diabetes_y_test, diabetes_y_pred))

# Plot outputs
j = 0
while j < length-1:
    plt.scatter(X, cc[j])
    plt.plot(x, bb[j], linewidth=3)
    j += 1
font2={'size' : 25}
plt.xlabel('$Neuron\ co-active\ N\ (10ms\ time\ bins)$', font2)
plt.ylabel('$Conditional\ Probability$', font2)
plt.tick_params(labelsize=25)
plt.title('$ Linear\ Regression\ for\ 40\ Clusters$', font2)
plt.show()




